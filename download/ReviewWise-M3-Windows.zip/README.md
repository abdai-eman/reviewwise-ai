# ReviewWise — Windows classroom edition

1. Download the Windows ZIP.
2. Right-click it → Extract All, then open the extracted folder.
3. Double-click **START_REVIEWWISE.bat** and keep its window open.

Python and the exact app packages are included. No terminal commands or pip installation are needed. Existing Ollama and qwen2.5:3b are reused. Missing Ollama/model files are prepared in the background; initial downloads need internet and may take several minutes (model approximately 1.9 GB). If WinGet is unavailable, install Ollama from https://ollama.com/download/windows first: four setup steps total.

For a presentation, open **Saved reports → Explore a recorded AI example**. It is a genuine recorded result, clearly labelled; it does not run new inference. Use **Analyse reviews** for new input and **Save this report** to keep your own results. A new 80-review analysis can still take minutes on a laptop.

Next time, double-click the same launcher. To stop, press Ctrl+C in its window. Quit Ollama from the Windows tray or use Release AI memory when finished.

Windows x64; Windows Server 2022 CI verified. Another person’s laptop test is still required. 8 GB RAM can be limiting; 16 GB is a recommendation, not a verified minimum. Remove personal details from input. Saved reports are stored only when explicitly saved.

Package checks: build-info.json. Architecture: docs/architecture.svg. Full source and documentation: https://github.com/abdai-eman/reviewwise-ai/tree/m3-mvp
